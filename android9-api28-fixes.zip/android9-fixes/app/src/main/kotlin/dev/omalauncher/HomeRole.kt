package dev.omalauncher

import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * RoleManager (API 29+) accessed only by reflection so that no Class reference
 * to RoleManager survives into the bytecode when minSdk < 29. R8 can otherwise
 * outline or inline a guarded call inside a composable and cause NoClassDefFoundError
 * on Android 9.
 */
object HomeRole {
    private const val CLASS = "android.app.role.RoleManager"
    private const val ROLE_HOME = "android.app.role.ROLE_HOME"

    fun supported(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q

    fun missing(context: Context): Boolean = runCatching {
        if (!supported()) return@runCatching false
        val cls = Class.forName(CLASS)
        val roles = context.getSystemService(cls) ?: return@runCatching false
        val available = cls.getMethod("isRoleAvailable", String::class.java)
            .invoke(roles, ROLE_HOME) as Boolean
        val held = cls.getMethod("isRoleHeld", String::class.java)
            .invoke(roles, ROLE_HOME) as Boolean
        available && !held
    }.getOrDefault(false)

    fun requestIntent(context: Context): Intent? = runCatching {
        if (!supported()) return@runCatching null
        val cls = Class.forName(CLASS)
        val roles = context.getSystemService(cls) ?: return@runCatching null
        cls.getMethod("createRequestRoleIntent", String::class.java)
            .invoke(roles, ROLE_HOME) as? Intent
    }.getOrNull()
}
